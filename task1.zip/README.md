# textClassifier for bing hackathon
text classification done using SVM

##Train & Test Data
tsv files converted to csv files & headers added for easiler usage.

###Train_Set
Train_Set has SlNo,Topic,Pub_Year,Authors,Title & Summary feilds
###Test_Set
Test_Set has ID,Topic,Pub_Year,Authors,Title & Summary feilds

##Dependencies
pandas - powerful Python data analysis toolkit
sklearn - Scikit-Learn

##How to Run?
Run the python script. It uses the train.csv & test.csv for training and testing.
It generates an output csv file(output.csv).

##Output
Output contains SlNo,ID,Pub_Year & Topic feilds.
